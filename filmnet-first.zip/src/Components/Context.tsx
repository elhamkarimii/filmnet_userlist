import { createContext } from "react";

export const StateContext:any = createContext({value:null});
