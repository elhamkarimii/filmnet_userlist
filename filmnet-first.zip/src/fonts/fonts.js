// import {createGlobalStyle} from 'styled-components'
// import Segoe from './Segoe.woff'
// export const GlobalFont = createGlobalStyle`
// @font-face {
//     font-family:"segoe" ;
//     src: url(${Segoe});
// }
// `